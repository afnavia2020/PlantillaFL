# Gatling Beginners Tutorial

**Course & support code is currently under construction**

The code is in this repository contains a Gatling script to test the [Gatling Computer Database](https://computer-database.gatling.io/computers), and supports the Gatling Open-Source and Gatling FrontLine beginners tutorial courses.

Courses can be found for free on the [Gatling YouTube](https://www.youtube.com/channel/UCaNih6sKuJ9DIMjTEW1EAlQ) channel